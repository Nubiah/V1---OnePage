$(document).ready(function(){

/**************************************************************************************************************/

		var $heightwd = $(window).height();
		var $widthwd = $(window).width();
    
	/**TAILLE IMAGE SLIDER**/
	/*$(window).resizeend({
	    onDragEnd: sliderresize,
	    runOnStart: true
	});

	function sliderresize () {
		if ($widthwd > 992) {
			$('.slider').css('height',$heightwd+'px');
		} else {
			$('.slider').css('height','auto');
		}
	};*/
	

	/**MENU COULISSANT**/

	if ($widthwd > 992) {
		$(".cadre-menu").hover(
			function() {
		    $(".cadre-menu").animate({marginLeft:"100px"}, 400 );
		  	},
		  	function(){
		    $(".cadre-menu").animate({marginLeft:"0"}, 300 );
		  	})};

	/**TAILLE MARGE TEXTE IMAGE SLIDER **/

	function verticalAlignCenter() {
    $(".verticalaligncenter").each(function() {
        var $elem = $(this);
        var elemHeight = $elem.height();
        if (elemHeight == 0)    // perhap's an element is no loaded
            return;
        var $container = $elem.parent();
        var paddingTop = Math.floor(($container.height() - elemHeight) / 2);
        if (paddingTop > 0)
            $elem.css("top", paddingTop);
	//        $elem.removeClass("verticalaligncenter");
    	});
	}	

	setInterval( function(){
    verticalAlignCenter();

	}, 250);

	/**APPARITION FONDU**/

	var $titre_page = $('.titre_page_2');
	var $img_titre_page = $('img_titre_page');
	$titre_page.fadeTo(2500, 1);
	$img_titre_page.fadeTo(3500, 1);

	/**SCROLL**/
	
	$('a[href^="#"]').click(function(){  
    var the_id = $(this).attr("href");  
  
    $('html, body').animate({scrollTop:$(the_id).offset().top}, 'slow');  
    	return false;  
	}); 

	/**SWIPEBOX**/

	$('.swipebox').swipebox();


/**************************************************************************************************************/
	});

/*(function($){
    $.resizeend = function(el, options){
        var base = this;
        
        base.$el = $(el);
        base.el = el;
        
        base.$el.data("resizeend", base);
        base.rtime = new Date(1, 1, 2000, 12,00,00);
        base.timeout = false;
        base.delta = 200;
        
        base.init = function(){
            base.options = $.extend({},$.resizeend.defaultOptions, options);
            
            if(base.options.runOnStart) base.options.onDragEnd();
            
            $(base.el).resize(function() {
                
                base.rtime = new Date();
                if (base.timeout === false) {
                    base.timeout = true;
                    setTimeout(base.resizeend, base.delta);
                }
            });
        
        };
        base.resizeend = function() {
            if (new Date() - base.rtime < base.delta) {
                setTimeout(base.resizeend, base.delta);
            } else {
                base.timeout = false;
                base.options.onDragEnd();
            }
        };
        
        base.init();
    };
    
    $.resizeend.defaultOptions = {
        onDragEnd : function() {},
        runOnStart : false
    };
    
    $.fn.resizeend = function(options){
        return this.each(function(){
            (new $.resizeend(this, options));
        });
    };



})(jQuery);	*/